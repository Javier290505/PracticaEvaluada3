/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practicaprogramada3;

import javax.swing.SwingUtilities;

/**
 *
 * @author jareg
 */
public class PracticaProgramada3 {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmpleadoSupervisor().setVisible(true));
    }
}
